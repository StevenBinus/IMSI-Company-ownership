package utils

func BoolPtr(b bool) *bool {
	return &b
}
